# Databricks notebook source
dbutils.fs.ls("/mnt/bronzecontainer")

# COMMAND ----------

from pyspark.sql import SparkSession


# COMMAND ----------

from pyspark.sql.functions import col, concat, lit

# COMMAND ----------

# To read the list of all the tables in our dbutils mounted bronzecontainer


table_name =[]
for i in dbutils.fs.ls("/mnt/bronzecontainer"):
    table_name.append(i.name.split('/')[0])

# COMMAND ----------

# To show or display the list of read tables in dbutils mounted bronzecontainer


table_name

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, concat,lit


for name in table_name:
    path = '/mnt/bronzecontainer' 
    print(path)
    dfgroup = spark.read.format('csv').option('header', 'true').load(path)
    dfgroup.printSchema()
    dfgroup = dfgroup.withColumn('DEDUCTIONS',col('GROSS_PAY')*0.09).withColumn('NETPAY', col('GROSS_PAY')-col('DEDUCTIONS'))

    output_path = "/mnt/goldcontainer"
    dfgroup.write.format("delta").mode("overwrite").save(output_path)

# COMMAND ----------

display(dfgroup)