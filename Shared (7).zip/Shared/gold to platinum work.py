# Databricks notebook source
dbutils.fs.ls('/mnt/goldcontainer')

# COMMAND ----------

# To read the list of all the tables in our dbutils mounted goldcontainer


table_name =[]
for i in dbutils.fs.ls("/mnt/goldcontainer"):
    table_name.append(i.name.split('/')[0])

# COMMAND ----------

# To show or display the list of read the parquet files in dbutils mounted goldcontainer


table_name

# COMMAND ----------

from pyspark.sql import SparkSession
from pyspark.sql.functions import col, concat,lit


for name in table_name:
    path = '/mnt/goldcontainer' 
    print(path)
    dfgroup1 = spark.read.format('delta').option('header', 'true').load(path)
    dfgroup1.printSchema()
    dfgroup1 = dfgroup1.withColumn('FULL_NAME',concat(col('FIRST_NAME'),lit(' -'),col('LAST_NAME')))

    output_path = "/mnt/platinumcontainer"
    dfgroup1.write.format("delta").mode("overwrite").save(output_path)

# COMMAND ----------

dfgroup1.display()