# Databricks notebook source
df_airline = (spark.read
  .format("jdbc")
  .option("url", "jdbc:sqlserver://sqlserver634.database.windows.net:1433;database=sqldbpw")
  .option("dbtable", "dbo.Airline")
  .option("user", "Aderemi")
  .option("password", "Erinayo19")
  .load()
)

# COMMAND ----------

display(df_airline)

# COMMAND ----------

from pyspark.sql.functions import col, concat, List
df_airline_new = df_airline.withColumnRenamed('Passenger ID', 'PassengerID').withColumnRenamed('First Name', 'FirstName').withColumnRenamed('Last Name', 'LastName').withColumnRenamed('Airport Name', 'AirportName').withColumnRenamed('Airport Country Code', 'AirportCountryCode').withColumnRenamed('Country Name', 'CountryName').withColumnRenamed('Airport Continents', 'AirportContinents').withColumnRenamed('Arrival Airport', 'ArrivalAirport').withColumnRenamed('Pilot Name', 'PilotName').withColumnRenamed('Flight Status', 'FlightStatus')

# COMMAND ----------

display(df_airline_new)

# COMMAND ----------

from pyspark.sql.functions import *

# COMMAND ----------

dbutils.fs.ls("/mnt/incremental-load-datemethod")

# COMMAND ----------

from pyspark.sql.functions import from_utc_timestamp, date_format
from pyspark.sql.types import TimestampType
from pyspark.sql.functions import date_format
from pyspark.sql.functions import col, concat, lit

df_airline1 = df_airline_new.withColumn("DepartureDate", to_date(col("DepartureDate"), "yyyyddMM"))

# COMMAND ----------

display(df_airline1)

# COMMAND ----------

output_path = "/mnt/incremental-load-datemethod"
cleaned_column_names = [col.replace(" ", "_") for col in df_airline1.columns]
df_airline1.toDF(*cleaned_column_names).write.format("delta").mode("overwrite").save(output_path)