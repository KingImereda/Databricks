# Databricks notebook source
dbutils.fs.mount(
source = 'wasbs://bronzecontainer@pworkdatalake.blob.core.windows.net',
mount_point = '/mnt/bronzecontainer',
extra_configs = {'fs.azure.account.key.pworkdatalake.blob.core.windows.net': '6LKxibfpc7El++PVoXbWxp2hpOZdN2BVcNEykjYbluV0aCxcwtm8lxIG2G9xXxkcFfAcmvGOfcro+ASt6TDDJA=='}
)

# COMMAND ----------

dbutils.fs.mount(
source = 'wasbs://goldcontainer@pworkdatalake.blob.core.windows.net',
mount_point = '/mnt/goldcontainer',
extra_configs = {'fs.azure.account.key.pworkdatalake.blob.core.windows.net': '6LKxibfpc7El++PVoXbWxp2hpOZdN2BVcNEykjYbluV0aCxcwtm8lxIG2G9xXxkcFfAcmvGOfcro+ASt6TDDJA=='}
)


# COMMAND ----------

dbutils.fs.mount(
source = 'wasbs://platinumcontainer@pworkdatalake.blob.core.windows.net',
mount_point = '/mnt/platinumcontainer',
extra_configs = {'fs.azure.account.key.pworkdatalake.blob.core.windows.net': '6LKxibfpc7El++PVoXbWxp2hpOZdN2BVcNEykjYbluV0aCxcwtm8lxIG2G9xXxkcFfAcmvGOfcro+ASt6TDDJA=='}
)


# COMMAND ----------

dbutils.fs.mounts()

# COMMAND ----------



# COMMAND ----------

dbutils.fs.mount(
source = 'wasbs://incremental-load-datemethod@pworkdatalake.blob.core.windows.net',
mount_point = '/mnt/incremental-load-datemethod',
extra_configs = {'fs.azure.account.key.pworkdatalake.blob.core.windows.net': '6LKxibfpc7El++PVoXbWxp2hpOZdN2BVcNEykjYbluV0aCxcwtm8lxIG2G9xXxkcFfAcmvGOfcro+ASt6TDDJA=='}
)
